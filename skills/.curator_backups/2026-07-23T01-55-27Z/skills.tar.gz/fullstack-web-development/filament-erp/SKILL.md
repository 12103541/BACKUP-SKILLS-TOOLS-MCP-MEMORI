---
name: filament-erp
category: fullstack-web-development
description: Patterns, pitfalls, and workflow for building Laravel + Filament v3.2 ERP applications — layout, forms, models, widgets, and business logic.
triggers:
  - Building or modifying Filament admin panel features
  - Laravel Filament form/table/page/widget issues
  - ERP module development with Filament resources
  - Filament layout, CSS, or rendering issues
  - Syncing business logic across Filament models (faktur, pajak, kontrak, etc.)
  - Auditing or analyzing ERP module logic flow
  - Entity conversion between modules (e.g., penawaran → kontrak)
  - RAB/RP budget calculation with auto-sum and markup
---

# Filament v3.2 ERP Development

Patterns and pitfalls for building production ERP with Laravel + Filament v3.2 on Laragon (Windows dev).

## Reference Files
- `references/faktur-pajak-sync-logic.md` — Faktur/Pajak/Kontrak sync state machine
- `references/scheduler-status-automation.md` — Cron commands and status automation
- `references/manajemen-proyek-flow.md` — Manajemen Proyek module analysis and fixes
- `references/rab-import-technical.md` — RAB Excel/CSV import technical details
- `references/livewire-filament-page-pitfalls.md` — Livewire property type errors: exact error→fix mappings for Filament Pages

## Environment

- Laragon at `C:\laragon\` — Apache + MySQL 8.0 + PHP 8.2
- Project root: `C:\laragon\www\<project-name>\`
- MySQL CLI: `"/c/laragon/bin/mysql/mysql-8.0.30-winx64/bin/mysql.exe" -u root <db> -e "<SQL>"`
- OPcache: `opcache.validate_timestamps=1` — must clear after every PHP class change
- Clear cache: `php artisan optimize:clear && php artisan filament:cache-components`
- PhpSpreadsheet requires `ext-zip` — verify with `php -m | grep zip`. If missing: add `extension=zip` to php.ini (DLL is at `C:\laragon\bin\php\php-X.X\ext\php_zip.dll`)

## Layout Pitfalls

### Filament Page Wrapper Grid

Filament's `<x-filament-panels::page>` wraps content in:
```html
<div class="grid flex-1 auto-cols-fr gap-y-8">
  <!-- your content here -->
</div>
```

**Problem**: Child `grid-cols-4` inside this wrapper gets treated as a grid item, not a nested grid. Cards stack vertically instead of aligning horizontally.

**Fix**: Use `flex` with `flex-1` on children, NOT `grid grid-cols-N`:
```html
<!-- WRONG — stacks vertically -->
<div class="grid grid-cols-4 gap-2 mb-6">

<!-- RIGHT — stays horizontal -->
<div class="flex gap-2 mb-6">
  <div class="flex-1 px-3 py-2 border ...">Card 1</div>
  <div class="flex-1 px-3 py-2 border ...">Card 2</div>
  <div class="flex-1 px-3 py-2 border ...">Card 3</div>
  <div class="flex-1 px-3 py-2 border ...">Card 4</div>
</div>
```

Also add `col-span-full` on outer divs to span the parent grid, though `flex` is more reliable.

### Filament SPA Footer Widgets
Footer widgets don't render in SPA mode. Use `getHeaderWidgets()` instead.

## Form Input Patterns

### Currency Inputs — No Spin Buttons, No Decimals
Filament `TextInput::make()->numeric()` renders `type="number"` with ugly spin buttons and decimal display (e.g., `4000000.00`).

**Fix**: Use Blade or custom HTML for currency fields:
```html
<input type="text" inputmode="numeric" value="{{ number_format($value, 0, ',', '.') }}"
       class="w-full rounded-lg border ...">
```

### Repeater with Auto-Calculated Totals
For invoice items (FakturItem pattern):
```php
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Placeholder;

Repeater::make('items')
    ->relationship('items')
    ->schema([
        TextInput::make('uraian')->label('Description')->required()->columnSpanFull(),
        TextInput::make('quantity')->label('Qty')->numeric()->required()->live()
            ->afterStateUpdated(fn (Get $get, Set $set) =>
                $set('total', (float)$get('quantity') * (float)$get('harga_satuan'))
            ),
        TextInput::make('harga_satuan')->label('Unit Price')->numeric()->prefix('Rp')->required()->live()
            ->afterStateUpdated(fn (Get $get, Set $set) =>
                $set('total', (float)$get('quantity') * (float)$get('harga_satuan'))
            ),
        TextInput::make('total')->label('Total')->numeric()->disabled()->dehydrated()->prefix('Rp'),
    ])
    ->collapsible()
    ->defaultItems(1)
    ->columns(3)
    ->columnSpanFull()
    ->itemLabel(fn (array $state): ?string => $state['uraian'] ?? null),

// Show summary below repeater
Grid::make(3)->schema([
    Placeholder::make('subtotal_display')
        ->label('Subtotal')
        ->content(fn (?Faktur $record): string => 'Rp ' . number_format($record?->subtotal ?? 0, 0, ',', '.')),
    // ... ppn, total_tagihan
]),

// Hidden fields to persist calculated values
Hidden::make('subtotal')->default(0),
Hidden::make('ppn')->default(0),
Hidden::make('total_tagihan')->default(0),
```

**Pitfall**: `Placeholder` only shows saved data on Edit. On Create, values are empty. Use `Hidden` fields with defaults to ensure save.

### Custom Filament Page Property Binding
When building a custom `Page implements HasForms` with Livewire/Blade, every form field name MUST have a matching `public` property on the Page class. Filament's form system reads/writes to these Livewire properties automatically.

```php
class ImportRab extends Page implements HasForms
{
    // CRITICAL: each form field needs a matching public property
    // CRITICAL: Livewire bans nullable type hints on public properties
    public array $parseResult = [];   // internal state (no form field), use array default
    public array $allSheets = [];     // internal state
    public string $rab_id = '';       // matches Select::make('rab_id')
    public $file = null;              // matches FileUpload::make('file') — NO TYPE HINT
    public bool $showPreview = false; // internal state
    public string $uploadedFilePath = ''; // internal state
}
```

**Pitfall 1**: If a form field is named `file` but the Page has no `public $file`, Livewire throws `Property [$file] not found on component` (500 error). Every `SomeField::make('x')` needs `public $x` on the Page class.

**Pitfall 2**: Do NOT use nullable type hints (`?string`, `?array`) on any Livewire-bound property. Three distinct 500 errors result:
- `?string $x = null` → "Property type not supported in Livewire for property: [null]"
- `?array $x = null` → "No synthesizer found for key: \"\""
- `string $file = ''` on a FileUpload property → same synthesizer error (TemporaryUploadedFile is an object, not a string)

**Rule**: ALL public properties on a Livewire Page must use concrete defaults: `string $x = ''`, `array $x = []`, `bool $x = false`. For FileUpload properties: `public $file = null` (no type hint at all). Livewire must be free to store whatever object type the upload mechanism uses.

**Pitfall 3**: The `afterStateUpdated` callback for FileUpload receives a TemporaryUploadedFile object, NOT a string path. To store it, call `$state->store('directory', 'disk')` explicitly:
```php
->afterStateUpdated(function ($state) {
    if ($state) {
        $path = is_object($state) && method_exists($state, 'getPath')
            ? $state->store('imports/rab', 'public')
            : (is_string($state) ? $state : null);
        if ($path) {
            $this->uploadedFilePath = $path;
            // now parse the file...
        }
    }
}),
```

## Model Patterns

### Boot Observer for Cross-Model Sync
When updating related models on status change (e.g., Faktur → KontrakTermin status sync):
```php
protected static function boot(): void
{
    parent::boot();

    static::updated(function (Faktur $faktur) {
        // CRITICAL: use wasChanged(), NOT isDirty()
        // isDirty() returns false in 'updated' callback because the model is already saved.
        if ($faktur->wasChanged('status') && $faktur->termin) {
            $statusMap = [
                'terbit'      => 'tertagih',
                'lunas'       => 'lunas',
                'draft'       => 'belum_tertagih',
                'jatuh_tempo' => 'terlambat',
            ];
            $newStatus = $statusMap[$faktur->status] ?? null;
            if ($newStatus) {
                $faktur->termin->update(['status' => $newStatus]);
            }
        }

        // Auto-create PPN when status changed to 'terbit'
        if ($faktur->wasChanged('status') && $faktur->status === 'terbit' && $faktur->ppn > 0) {
            $faktur->createPpnKeluaran();
        }

        // Recalculate kontrak progress when status changed to 'lunas'
        if ($faktur->wasChanged('status') && $faktur->status === 'lunas') {
            $faktur->kontrak?->hitungProgresOtomatis();
        }
    });
}
```

**Pitfall 1**: `static::updating` vs `static::updated` — use `updated` if the observer needs to read the NEW status value. `updating` fires before save, so `$record->status` is the OLD value.

**Pitfall 2**: `isDirty()` vs `wasChanged()` — in `updated` callback, the model is already saved to DB, so `isDirty()` always returns false. Use `wasChanged('field')` to check if a field actually changed during the save.

**Pitfall 3**: Eloquent observers only fire via Eloquent (`Model::update()`, `Model::save()`). Direct SQL (`UPDATE ... SET`) bypasses them entirely. When E2E testing, always use `php artisan tinker --execute="..."` or a test script with Eloquent, not raw SQL.

### Auto-Create Related Records (Faktur → PPN Keluaran)
```php
public function createPpnKeluaran(): void
{
    // Dedup check
    $exists = Pajak::where('faktur_id', $this->id)
        ->where('jenis', 'ppn_keluaran')
        ->exists();
    if ($exists) return;

    Pajak::create([
        'jenis' => 'ppn_keluaran',
        'faktur_id' => $this->id,
        'kontrak_id' => $this->kontrak_id,
        // Derive tarif from actual data, not hardcoded
        'tarif_pajak' => $this->subtotal > 0
            ? round(($this->ppn / $this->subtotal) * 100, 2)
            : (float) config('pajak.tarif_ppn_keluaran', 12),
        // ... other fields from faktur
    ]);
}
```

**Pitfall**: Always dedup-check before creating related records, because `updated` event fires on every save, not just the first publish.

**Pitfall**: Never hardcode tarif pajak (e.g., `11`). Derive from `ppn/subtotal` ratio or use `config('pajak.tarif_ppn_keluaran')`. Tax rates change (PPN went from 11% to 12% in 2025). Create `config/pajak.php` for defaults.

### Bidirectional Status Sync (Reverse Sync)
Faktur→Termin sync alone is NOT enough. When user marks termin as paid in Kontrak page, the faktur must also update. Add reverse sync to the related model:

```php
// In KontrakTermin model
protected static function boot(): void
{
    parent::boot();
    static::updated(function (KontrakTermin $termin) {
        if ($termin->wasChanged('status') && $termin->faktur) {
            if ($termin->status === 'lunas' && $termin->faktur->status !== 'lunas') {
                $termin->faktur->update([
                    'status' => 'lunas',
                    'tanggal_pembayaran' => now(),
                ]);
            } elseif ($termin->status === 'belum_tertagih' && $termin->faktur->status === 'lunas') {
                $termin->faktur->update(['status' => 'draft']);
            }
        }
    });
}
```

### Cleanup on Delete/Restore (Faktur → Pajak + Progres)
When a record is deleted, related auto-created records must be cleaned up:

```php
// In Faktur boot()
static::deleted(function (Faktur $faktur) {
    // Remove auto-created PPN records
    Pajak::where('faktur_id', $faktur->id)->delete();
    // Recalculate kontrak progres
    $faktur->kontrak?->hitungProgresOtomatis();
});

static::restored(function (Faktur $faktur) {
    if ($faktur->ppn > 0 && $faktur->status === 'terbit') {
        $faktur->createPpnKeluaran();
    }
    $faktur->kontrak?->hitungProgresOtomatis();
});
```

### Cleanup on Reopen (Kontrak → Aset)
When kontrak status changes from 'completed' back to 'active', delete auto-created asets:

```php
// In Kontrak model — detect reopen
if ($kontrak->wasChanged('status') && $kontrak->status === 'active' && $oldStatus === 'completed') {
    $kontrak->aset()->where('catatan', 'like', '%dibuat otomatis%')->each(function ($aset) {
        $aset->riwayat()->delete();
        $aset->delete();
    });
}
```

### Progres Keuangan — Do Not Double-Count
```php
// WRONG — adds cost + revenue
$totalRealisasi = $pengeluaran + $fakturLunas;

// RIGHT — revenue only (faktur lunas / nilai kontrak)
$progresKeuangan = $fakturLunas / $nilaiKontrak * 100;
```

Keep cost tracking separate from revenue tracking.

## Navigation & Routing

### Moving Resources Between Sidebar Groups
To move a resource into a different sidebar group, add `navigationGroup` to the resource class:
```php
class KlienResource extends Resource
{
    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';
    protected static ?string $navigationGroup = 'Manajemen Proyek';  // ← ADD THIS

    // All resources in same group will cluster together in sidebar
    // Group order is determined by the first resource that defines it
}
```
**Pitfall**: If a resource has no `navigationGroup`, it lands in the default (ungrouped) section. Group name must match exactly (case-sensitive) across all resources in that group.

### Linking Faktur to KontrakTermin
When a faktur must reference a specific kontrak termin (payment milestone):
1. Add `kontrak_termin_id` column to `faktur` table
2. Add to `$fillable` in Faktur model
3. Add `belongsTo(KontrakTermin::class)` relationship
4. In form: Select field filtered by kontrak_id + status 'belum_tertagih'
5. When termin selected: auto-fill subtotal from `termin.nilai`, jatuh_tempo from `termin.tgl_jatuh_tempo`
6. Reset termin when kontrak changes: `afterStateUpdated` on kontrak_id clears kontrak_termin_id
7. When faktur status changes: sync termin status via boot observer

### Custom Pages vs Resource Pages
- `Filament\Pages\Page` for mixed content (forms + tables + settings)
- Must register in `AdminPanelProvider::pages()`, NOT in Resource `getPages()`
- `getNavigationItems()` does NOT exist in Filament v3.2 — use PanelProvider registration

### AdminPanelProvider Backslash Escaping
```php
// WRONG — quadruple backslash breaks resources
discoverResources(for: 'App\\\\\\Filament\\\\\\Resources')

// RIGHT — double backslash
discoverResources(for: 'App\\Filament\\Resources')
```

## RBAC & Dept Access

Use `HasDeptAccess` trait + permission-based `canAccess()`:
```php
use App\Filament\Traits\HasDeptAccess;

class SomeResource extends Resource
{
    use HasDeptAccess;
    protected static ?string $navSlug = 'some_resource';

    public static function canAccess(): bool
    {
        return Auth::user()->hasPermission('some_resource.view');
    }
}
```

## File Upload Pattern

### Bukti/Struk Upload
```php
// Model: cast to string
protected $casts = ['bukti_struk' => 'string'];

// Form
FileUpload::make('bukti_struk')
    ->label('Bukti / Struk')
    ->directory('bukti-transaksi')
    ->image()
    ->maxSize(2048)
    ->nullable(),

// Blade view
@if(!empty($item['bukti_struk']))
    <a href="{{ Storage::url($item['bukti_struk']) }}" target="_blank" class="text-primary-600">
        📎 Lihat Bukti
    </a>
@endif
```

## Scheduler for Status Automation

Use artisan commands + `routes/console.php` for daily status updates:

```php
// routes/console.php
Schedule::command('faktur:check-overdue')->dailyAt('07:00');
Schedule::command('termin:update-overdue')->dailyAt('07:30');
Schedule::command('faktur:reminder-jatuh-tempo')->dailyAt('08:00');
Schedule::command('aset:check-garansi')->dailyAt('09:00');
```

### Standard ERP Scheduler Commands

| Command | Schedule | Purpose |
|---------|----------|---------|
| `faktur:check-overdue` | 07:00 | `terbit` + overdue → `jatuh_tempo`, sync termin → `terlambat` |
| `termin:update-overdue` | 07:30 | `tertagih` + overdue → `terlambat` |
| `faktur:reminder-jatuh-tempo` | 08:00 daily | H-7 and H-1 reminders for faktur + termin (logs to Activity) |
| `aset:check-garansi` | 09:00 daily | Log warranty expiration for active assets |
| `penawaran:check-expired` | 10:00 daily | Auto-expire penawaran past their masa_berlaku |

### Reminder Command Pattern (H-7 / H-1)
```php
// Check for due dates at H-7 and H-1
$h7 = Faktur::where('status', 'terbit')
    ->whereDate('jatuh_tempo', now()->addDays(7)->toDateString())
    ->get();
// Log to Activity model for in-app notification
```

**Pitfall**: Always use Eloquent (not raw SQL) for scheduler commands that need to trigger observers. If you need status changes to cascade, use `$model->update()` not `DB::table()->where()->update()`.

```php
// app/Console/Commands/CheckFakturOverdue.php
protected $signature = 'faktur:check-overdue';

public function handle(): int
{
    $overdue = Faktur::where('status', 'terbit')
        ->whereDate('jatuh_tempo', '<', now()->toDateString())
        ->get();

    foreach ($overdue as $faktur) {
        $faktur->update(['status' => 'jatuh_tempo']);
        if ($faktur->termin) {
            $faktur->termin->update(['status' => 'terlambat']);
        }
    }

    return self::SUCCESS;
}
```

## Auto-Generate Transaction Codes

Pattern: `PREFIX/YYYY/MM/NNN` (e.g., `TU/2026/07/001`)

```php
public static function generateKodeTransaksi(string $prefix = 'TU'): string
{
    $now = now();
    $pattern = $prefix . '/' . $now->format('Y/m') . '/%';
    $last = static::where('kode_transaksi', 'LIKE', $pattern)
        ->orderBy('kode_transaksi', 'desc')
        ->value('kode_transaksi');

    if ($last) {
        $num = (int) substr($last, -3) + 1;
    } else {
        $num = 1;
    }

    return $prefix . '/' . $now->format('Y/m') . '/' . str_pad($num, 3, '0', STR_PAD_LEFT);
}
```

**Pitfall**: Preview the code in the form (read-only field), but generate the ACTUAL code in the model's `create()` or `topUp()` method — not in the form's `default()` — to avoid race conditions.

## Entity Conversion Pattern (Penawaran → Kontrak)

When a record can be "promoted" to another entity (e.g., Penawaran → Kontrak):

```php
// In PenawaranResource table actions
Tables\Actions\Action::make('konversi_ke_kontrak')
    ->label('Buat Kontrak')
    ->icon('heroicon-o-document-check')
    ->color('success')
    ->requiresConfirmation()
    ->form([
        Select::make('klien_id')->relationship('klien', 'nama')
            ->searchable()->preload()->required(),
        DatePicker::make('tgl_mulai')->required(),
        DatePicker::make('tgl_akhir')->required(),
        TextInput::make('nilai')->numeric()->prefix('Rp')->required(),
    ])
    ->action(function (Penawaran $record, array $data): void {
        $kontrak = Kontrak::create([
            'nomor_kontrak' => 'KTR/' . strtoupper(substr($record->nomor_penawaran, 0, 10))
                . '/' . now()->format('Y'),
            'nama_kontrak' => $record->deskripsi_pekerjaan,
            'klien_id' => $data['klien_id'],
            'nama_klien' => Klien::find($data['klien_id'])?->nama ?? $record->nama_klien,
            'nilai' => $data['nilai'],
            'tgl_mulai' => $data['tgl_mulai'],
            'tgl_akhir' => $data['tgl_akhir'],
            'status' => 'active',
            'user_id' => auth()->id(),
        ]);
        $record->update(['kontrak_id' => $kontrak->id, 'status' => 'approved']);
        Notification::make()->success('Kontrak ' . $kontrak->nomor_kontrak . ' dibuat!')->send();
    })
    ->visible(fn (Penawaran $record) => $record->status !== 'approved' && is_null($record->kontrak_id));
```

**Pitfall**: Hide the action when already converted (`kontrak_id` not null) or already approved.

## Form Field Type Discipline

**Always use Select for relationships and enums, NEVER TextInput:**

```php
// WRONG — user can type garbage
TextInput::make('status')->required(),
TextInput::make('kontrak_id')->numeric(),
TextInput::make('user_id')->numeric(),

// RIGHT — enforced options
Select::make('status')
    ->options(['draft' => 'Draft', 'submitted' => 'Diajukan', 'approved' => 'Disetujui'])
    ->default('draft')
    ->native(false),
Select::make('kontrak_id')
    ->relationship('kontrak', 'nomor_kontrak')
    ->searchable()->preload()->nullable(),
// user_id: auto-set in Create page via mutateFormDataBeforeCreate
```

**Pitfall**: Text fields for status/foreign keys lead to inconsistent data. Always use Select or Enum.

## Child → Parent Progress Auto-Recalculate

When a child record's status affects parent progress (e.g., Pekerjaan → Kontrak progres_fisik):

```php
// In Pekerjaan model
protected static function boot(): void
{
    parent::boot();
    static::updated(function (Pekerjaan $pekerjaan) {
        if ($pekerjaan->wasChanged('status')) {
            if ($pekerjaan->status === 'approved') {
                $pekerjaan->updateQuietly([
                    'approved_by' => auth()->id(),
                    'approved_at' => now(),
                ]);
            } elseif ($pekerjaan->getOriginal('status') === 'approved') {
                $pekerjaan->updateQuietly([
                    'approved_by' => null,
                    'approved_at' => null,
                ]);
            }
            // Always recalculate parent progress on status change
            $pekerjaan->kontrak?->hitungProgresOtomatis();
        }
    });
}
```

**Pitfall**: Use `updateQuietly()` inside observer to avoid infinite loop (observer triggers another save → observer again).

## Dynamic helperText from Cross-Model Lookup

Show reference data as helperText on form fields:

```php
TextInput::make('harga_satuan')
    ->required()->numeric()->prefix('Rp')
    ->live()
    ->afterStateUpdated(...)
    ->helperText(function ($get) {
        $uraian = $get('uraian_pekerjaan');
        if (!$uraian || strlen($uraian) < 3) return null;
        $ref = HargaReferensi::cariHarga($uraian);
        return $ref
            ? 'Harga pasar: Rp' . number_format($ref->harga_rata2, 0, ',', '.') . ' (' . $ref->sumber . ')'
            : null;
    }),
```

**Pattern**: Use `helperText` with a callback that queries a reference table. Returns null when no match.

## RAB Total Auto-Calculate from Child Records

When parent total must be sum of children:

```php
// In Rab model
protected static function boot(): void
{
    parent::boot();
    static::saved(function (Rab $rab) {
        if ($rab->relationLoaded('komponen')) {
            $rab->hitungTotal();
        }
    });
}

public function hitungTotal(): void
{
    $total = (float) $this->komponen()->sum('jumlah_harga');
    if ($this->is_markup_applied && $this->markup_persen > 0) {
        $total = $total * (1 + $this->markup_persen / 100);
    }
    $this->updateQuietly(['total_rab' => $total]);
}
```

**Pitfall**: Use `updateQuietly()` inside `saved` observer to avoid infinite recursion.

## Scheduler for Expired Records

Auto-update status for time-sensitive records (Penawaran, Kontrak):

```php
// app/Console/Commands/CheckPenawaranExpired.php
$expired = Penawaran::whereNotIn('status', ['approved', 'rejected', 'expired'])
    ->whereRaw('DATE_ADD(tanggal_penawaran, INTERVAL masa_berlaku DAY) < NOW()')
    ->get();

foreach ($expired as $penawaran) {
    $penawaran->update(['status' => 'expired']);
}
```

Register in `routes/console.php`: `Schedule::command('penawaran:check-expired')->dailyAt('10:00');`

**Pitfall**: Exclude 'approved' and 'rejected' from the check — only expire records that are still pending.

## Resource Index Stats Columns

Add computed statistics to resource table:

```php
// In model
public function getKontrakAktifCountAttribute(): int
{
    return $this->kontrak()->where('status', 'active')->count();
}

// In Resource table
TextColumn::make('kontraks_count')
    ->counts('kontrak')
    ->label('Total Kontrak')
    ->sortable(),
TextColumn::make('kontrak_aktif')
    ->label('Aktif')
    ->getStateUsing(fn ($record) => $record->kontrak()->where('status', 'active')->count())
    ->sortable(),
```

## ERP Flow Analysis Methodology

When auditing ERP module logic, follow this systematic approach:

1. **Read all models** in the module — check fillable, relationships, observers
2. **Read all resources** — check form fields, table columns, actions
3. **Trace the business flow** — map each step: what triggers what
4. **Identify gaps**: missing observers, unidirectional sync, hardcoded values
5. **Categorize by severity**: KRITIS (broken flow) → SEDANG (incomplete) → RENDAH (nice-to-have)
6. **Check bidirectional sync** — if A→B sync exists, does B→A also exist?
7. **Check cleanup** — delete/restore/reopen all need handling
8. **Check scheduler** — time-sensitive statuses need automated checks

## Excel/CSV Import Pattern (RAB from File)

### Architecture
```
Upload File → RabImportService::parse() → Preview → Confirm → import() → RabKomponen::create()
```

### Service Class Pattern
```php
// app/Services/RabImportService.php
class RabImportService
{
    // Column detection via keyword matching
    private array $headerKeywords = [
        'uraian_pekerjaan' => ['uraian', 'item', 'nama', 'pekerjaan', 'deskripsi'],
        'volume'           => ['volume', 'qty', 'quantity', 'jumlah'],
        'satuan'           => ['satuan', 'unit', 'uom'],
        'harga_satuan'     => ['harga', 'harga satuan', 'price', 'biaya'],
        'jumlah_harga'     => ['total', 'jumlah', 'subtotal', 'amount'],
    ];

    public function parse(): array
    {
        $spreadsheet = IOFactory::load($this->filePath);
        $rows = $spreadsheet->getActiveSheet()->toArray(null, true, true, false);
        // Auto-detect header row by keyword matching
        // Map columns, filter empty/total rows
        // Parse numeric values (Indonesian format: 1.500.000,50)
        return ['columns' => $columns, 'rows' => $data, 'total' => $totalDetected];
    }

    public function import(Rab $rab, array $data, float $markupPersen = 0): int
    {
        foreach ($data as $item) {
            RabKomponen::create([...]);
        }
        $rab->hitungTotal();
        return count($data);
    }
}
```

### Filament Page Pattern
```php
// app/Filament/Resources/RabResource/Pages/ImportRab.php
class ImportRab extends Page implements HasForms
{
    public ?array $parseResult = null;
    public bool $showPreview = false;

    public function form(Form $form): Form
    {
        return $form->schema([
            Select::make('rab_id')->relationship('rab', 'nomor_rab')->required()->live(),
            FileUpload::make('file')
                ->acceptedFileTypes([...])
                ->directory('imports/rab')
                ->live()
                ->afterStateUpdated(fn ($state) => $this->processFile($state)),
        ]);
    }

    public function processFile(string $path): void
    {
        $service = new RabImportService(Storage::disk('public')->path($path));
        $this->parseResult = $service->parse();
        $this->showPreview = true;
    }
}
```

### Key Patterns
- **Header detection**: scan rows for keyword matches, pick row with highest score
- **Column mapping with scoring**: NOT first-match. Use scoring: exact match = 100 points, contains = keyword_length * 5. Pick best score per column. This prevents "Jumlah" from matching `volume` before `jumlah_harga`.
- **Keyword priority**: Put more specific keywords first (e.g., "harga satuan" before "harga", "jumlah harga" before "jumlah"). Remove ambiguous single-word keywords that overlap fields. Include multilingual variants (e.g., "hang muc" for Vietnamese BOQ headers, "unit price"/"total price" for English).
- **Multi-sheet import**: Real Excel files have multiple sheets (summary + detail). Parse ALL sheets with `parseAllSheets()`, skip sheets with 0 items, show per-sheet preview, import all at once with `importAllSheets()`. Pattern:
```php
public function parseAllSheets(): array {
    $spreadsheet = IOFactory::load($this->filePath);
    $results = [];
    foreach ($spreadsheet->getSheetNames() as $name) {
        try {
            $service = new self($this->filePath, $name);
            $result = $service->parse();
            if (count($result['rows']) > 0) $results[$name] = $result;
        } catch (\Throwable) { continue; }
    }
    return $results;
}
```
- **Numeric parsing**: handle `1.500.000,50` (Indonesian) and `1500000.50` (standard)
- **Skip logic**: ignore empty rows, "TOTAL", "SUB TOTAL", "GRAND TOTAL"
- **Library**: PhpSpreadsheet 1.30 (via maatwebsite/excel), handles .xlsx/.xls/.csv. Requires ext-zip (add `extension=zip` to php.ini if missing). `setCalculationEnabled()` does NOT exist in v1.30.
- **Formula errors**: `toArray()` throws `CalculationException` on broken formulas (#REF!, deleted sheets). Real-world Excel files (especially BOQ/quotations with cross-sheet references) ALWAYS have these. Wrap in try-catch, fall back to cell-by-cell `getCalculatedValue()` with inner try-catch. Pattern:
```php
$rows = [];
try {
    $rows = $targetSheet->toArray(null, true, true, false);
} catch (\Throwable) {
    for ($r = 1; $r <= $highestRow; $r++) {
        $row = [];
        for ($c = 1; $c <= $highestColIndex; $c++) {
            try {
                $cell = $targetSheet->getCellByColumnAndRow($c, $r);
                $val = $cell->getCalculatedValue(); // try evaluated
            } catch (\Throwable) {
                try { $val = $cell->getValue(); }    // fallback raw
                catch (\Throwable) { $val = null; }
            }
            $row[] = $val;
        }
        $rows[] = $row;
    }
}
```
- **Preview**: show first 5 rows per sheet + column mapping; show total items count across all sheets

### Registration
```php
// In RabResource::getPages()
'import' => Pages\ImportRab::route('/import'),

// In ListRabs header actions
Actions\\Action::make('import')
    ->label('Import dari File')
    ->url(fn () => RabResource::getUrl('import'))
    ->icon('heroicon-o-arrow-up-tray'),
```

## Common Pitfalls

| Issue | Cause | Fix |
|-------|-------|-----|
| Page blank, no errors | SPA mode + footer widgets | Use getHeaderWidgets() |
| Resources disappear from sidebar | Quadruple backslash in discoverResources | Use double backslash `\\` |
| Font too large in widgets | `text-sm` default in tables | Use `text-xs` explicitly |
| Stat cards stack vertically | Filament grid wrapper conflicts | Use `flex` + `flex-1` |
| Currency shows decimals | `type="number"` input | Use `type="text" inputmode="numeric"` |
| Observer fires with old status | Using `static::updating` | Use `static::updated` |
| Observer doesn't trigger at all | Using `isDirty()` inside `updated` callback | Use `wasChanged()` — `isDirty` returns false after save |
| Eloquent observer not firing | Testing via raw SQL (`UPDATE ... SET`) | Observers only fire via Eloquent; test with `Model::find()->update()` or `artisan tinker` |
| Auto-create duplicates | No dedup check | Always check exists() before create |
| Progres double-counts | Cost + revenue summed | Track tagihan and biaya separately |
| Resource appears in wrong sidebar group | Missing `navigationGroup` property | Add `protected static ?string $navigationGroup = 'GroupName';` to resource class |
| Form has extra fields user didn't ask for | Agent adds fields proactively | Only add fields the user explicitly requests; don't assume "top up needs bukti" etc. User said "kamu salah logic" when Tanggal+Bukti were added to top-up form without being asked |
| Navigation label mismatch | Copying old labels when renaming | When renaming a page (e.g., "Top Up & Pengaturan" → "Top Up Petty Cash"), update ALL: `$navigationLabel`, `$title`, section headings, sidebar link text |
| Reverse sync missing | Only Faktur→Termin direction coded | Always implement bidirectional sync: add boot observer on both sides (Faktur + KontrakTermin) |
| Delete doesn't cleanup | Related auto-created records orphaned | Add `static::deleted()` to clean up auto-created records (Pajak, etc.) and recalculate progres |
| Hardcoded tax rate breaks later | `tarif_pajak = 11` written once | Derive from actual data (`ppn/subtotal * 100`) or use `config('pajak.tarif_ppn')` with env fallback |
| Aset not cleaned on reopen | Kontrak → completed → active transition | Detect reopen: if `wasChanged('status') && status === 'active'`, delete auto-created aset records |
| No reminder before due date | Only overdue checker, no advance notice | Add H-7/H-1 reminder command that logs to Activity for in-app notification |
| PPN tarif default stale | Default 11% left after 12% rate change | Create `config/pajak.php` with env-driven defaults; update `jenisTarif` array in PajakResource |
| E2E test passes but production fails | Test used raw SQL, observer never fired | Always use Eloquent for E2E: `php artisan tinker --execute` or test scripts with `Model::create()` / `->update()` |
| TextInput for status/foreign keys | Form shows free-text input for enum or relation fields | Always use Select::make() with options/relationship — TextInput leads to inconsistent data |
| Child status change doesn't update parent | No observer on child model | Add boot observer on child: on status change → call parent's hitungProgresOtomatis() |
| Penawaran never expires | isExpired() checks status==='draft' only | Fix to: status !== 'approved' AND past masa_berlaku; add scheduler to auto-update |
| RAB total stays 0 after save | total_rab field disabled, not dehydrated, no calculation | Add Rab::saved() observer that calls hitungTotal() summing komponen |
| Cross-model lookup not showing | No dynamic reference in form | Use helperText(callback) that searches reference model by current field value |
| Klien index has no stats | Missing kontrak counts | Add `counts('kontrak')` column + computed `kontrak_aktif` attribute |
| Custom Page 500 Property not found | Form field has no matching public property on Page class | Add `public $fieldName = null` for every `make('fieldName')` in the form schema |
| Livewire "Property type not supported" | Using nullable type hint `?string $field = null` on a Livewire property | Use non-nullable with default: `public string $field = ''`. Livewire doesn't support `?type` property declarations — it throws "Property type not supported in Livewire for property: [null]" |
| FileUpload 500: "No synthesizer found for key: \"\"" | `FileUpload::make('file')` stores a Livewire TemporaryUploadedFile object; `public string $file = ''` type-hint causes Livewire to fail serialization | Use `public $file = null` with NO type hint at all. Livewire needs to store an object, not a string. Also, `?array $x = null` triggers the same error — use `array $x = []` instead. ALL Livewire-bound properties must avoid nullable type hints: `public string $x = ''` not `?string $x = null`; `public array $x = []` not `?array $x = null`; `public $x = null` for FileUpload |
| ImportAction doesn't exist in Filament v3 | Code copied from older docs or AI hallucination | Use `Actions\Action::make('name')` with `->url()` for navigation buttons |
| Column auto-detect matches wrong field | First-match strategy picks early fields for ambiguous names | Use scoring: exact=100, contains=length*5; put specific keywords before generic ones |
| `is_markup_applied` column missing | Model references column not in DB migration | Add column: `ALTER TABLE rab ADD COLUMN is_markup_applied TINYINT(1) DEFAULT 0` |
| PhpSpreadsheet ZipArchive error | ext-zip not enabled in php.ini | Add `extension=zip` to php.ini (DLL exists in Laragon PHP ext dir) |
