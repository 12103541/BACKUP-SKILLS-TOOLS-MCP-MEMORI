# Livewire + Filament Page Property Pitfalls

Concrete error→fix mappings discovered across sessions. These are the Livewire landmines when building custom Filament Pages with `HasForms`.

## Error Catalog

### 1. "Property [$x] not found on component"
**Cause**: Form field `SomeField::make('x')` exists but the Page class has no `public $x`.
**Fix**: Add `public $x = null;` (or appropriate default) to the Page class.

### 2. "Property type not supported in Livewire for property: [null]"
**Cause**: `public ?string $rab_id = null;` — Livewire can't synthesize nullable types.
**Fix**: `public string $rab_id = '';` — use non-nullable with empty-string default.

### 3. "No synthesizer found for key: \"\""
**Cause A**: `public ?array $allSheets = null;` — same nullable issue, different error.
**Fix A**: `public array $allSheets = [];` — use non-nullable with array default.

**Cause B**: `public string $file = ''` on a FileUpload property. Livewire's file upload stores a `TemporaryUploadedFile` object (not a string), and the string type-hint prevents serialization.
**Fix B**: `public $file = null;` — remove type hint entirely. Livewire needs freedom to store objects.

### 4. FileUpload callback receives TemporaryUploadedFile, not path string
**Cause**: `afterStateUpdated(fn ($state) => ...)` — `$state` is a Livewire TemporaryUploadedFile object.
**Fix**: Detect and store explicitly:
```php
->afterStateUpdated(function ($state) {
    if ($state) {
        $path = is_object($state) && method_exists($state, 'getPath')
            ? $state->store('target/directory', 'public')
            : (is_string($state) ? $state : null);
        if ($path) {
            $this->filePath = $path;
        }
    }
}),
```

## Universal Rule

ALL public properties on a Filament Livewire Page that will be bound to form fields must follow:

| Field Type | Property Declaration | Why |
|-----------|---------------------|-----|
| TextInput, Select, etc. | `public string $x = '';` | Livewire needs concrete type |
| Checkbox, Toggle | `public bool $x = false;` | Livewire needs concrete type |
| Array state | `public array $x = [];` | Never `?array` |
| FileUpload | `public $x = null;` | No type hint — TemporaryUploadedFile object |

Internal-only properties (not bound to form fields) can use nullable types since they're never serialized by Livewire's form system — but to be safe, use concrete defaults everywhere.

## Testing Pattern

After adding a new Page with forms, always:
1. Load the page in browser — check for 500 errors
2. Interact with each form field — check for Livewire update errors
3. For FileUpload: upload a test file, verify `afterStateUpdated` fires
4. Check `storage/logs/laravel.log` for "No synthesizer" or "Property type not supported"
