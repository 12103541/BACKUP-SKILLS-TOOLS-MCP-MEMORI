# RAB Import — Technical Reference (July 23, 2026)

## Files Created
- `app/Services/RabImportService.php` — Parsing + import logic
- `app/Filament/Resources/RabResource/Pages/ImportRab.php` — Filament page
- `resources/views/filament/resources/rab-resource/pages/import-rab.blade.php` — Blade view

## DB Requirement
```sql
ALTER TABLE rab ADD COLUMN is_markup_applied TINYINT(1) NOT NULL DEFAULT 0 AFTER markup_persen;
```

## Auto-Detect Header Algorithm

Step 1 — Find header row:
```php
// Score each row by keyword matches. Row with score >= 20 wins.
foreach ($rows as $i => $row) {
    foreach ($row as $cell) {
        foreach ($this->headerKeywords as $field => $keywords) {
            foreach ($keywords as $keyword) {
                if (str_contains($normalized, $keywordNorm)) {
                    $score += 10;
                }
            }
        }
    }
}
return ($maxScore >= 20) ? $bestRow : null;
```

Step 2 — Map columns with SCORING (NOT first-match):
```php
// Exact match = 100 points, Contains = len(keyword) * 5
// Best field per column wins
foreach ($this->headerKeywords as $field => $keywords) {
    foreach ($keywords as $keyword) {
        if ($lower === $keywordNorm) {
            $score = 100; // exact
        } elseif (str_contains($lower, $keywordNorm)) {
            $score = strlen($keywordNorm) * 5; // longer = more specific
        }
        if ($score > $bestScore) {
            $bestScore = $score;
            $bestField = $field;
        }
    }
}
```

### Keyword Priority (specific → generic)
```php
'harga_satuan' => ['harga satuan', 'harga/satuan', 'harga', 'rupiah', 'price'],
'jumlah_harga' => ['total', 'jumlah harga', 'subtotal', 'jumlah', 'amount'],
'volume'       => ['volume', 'qty', 'quantity', 'kuantitas', 'vol'],
```
"harga satuan" (2 words, length=11) scores 55 for header "Harga Satuan"
"satuan" (length=6) scores 30
→ "harga satuan" wins correctly.

## Indonesian Number Format Handling
```php
// Input: "1.500.000,50" or "Rp1.500.000" or "1500000.50"
$str = str_replace(['Rp', ' '], '', $str);
$str = str_replace('.', '', $str);   // remove thousand separator
$str = str_replace(',', '.', $str);  // comma → decimal
return (float) $str;
```

## Skip Patterns
- Empty rows: all cells null/empty
- Total rows: first cell contains "total", "subtotal", "jumlah", "grand total"
- Short uraian (< 3 chars)

## PhpSpreadsheet Notes
- Version 1.30.5 (required by maatwebsite/excel ^1.30.4)
- ext-zip REQUIRED for .xlsx — add `extension=zip` to php.ini if missing
- DLL exists at `C:\laragon\bin\php\php-X.X\ext\php_zip.dll`
- `IOFactory::load()` handles .xlsx, .xls, .csv automatically

## Livewire Property Binding
Custom Filament Pages (`Page implements HasForms`) need public properties matching each form field name:
```php
// CORRECT — use non-nullable string with default ''
public string $rab_id = '';  // Select::make('rab_id')
public string $file = '';    // FileUpload::make('file')

// WRONG — nullable causes "Property type not supported in Livewire"
public ?string $sheet = null;  // ← DON'T DO THIS
```
Missing property → `Property [$file] not found` 500 error.
Nullable type → `Property type not supported in Livewire for property: [null]` 500 error.

## Multi-Sheet Import Pattern

When an Excel file has multiple sheets (e.g., BOQ per charger type):

```php
// parseAllSheets() — iterate all sheets, skip empty ones
public function parseAllSheets(): array
{
    $spreadsheet = IOFactory::load($this->filePath);
    $results = [];
    foreach ($spreadsheet->getSheetNames() as $name) {
        try {
            $service = new self($this->filePath, $name);
            $result = $service->parse();
            if (count($result['rows']) > 0) {
                $results[$name] = $result;
            }
        } catch (\Throwable $e) { continue; }
    }
    return $results;
}

// importAllSheets() — import all parsed sheets into one RAB
public function importAllSheets(Rab $rab, array $allSheetData): int
{
    $total = 0;
    foreach ($allSheetData as $data) {
        $total += $this->import($rab, $data['rows']);
    }
    return $total;
}
```

UI: Show sheet summary (name + item count), per-sheet preview (5 rows), single "Import Semua" button.

**Pitfall**: Some sheets are dashboards/summaries (e.g., "RESUME" with cross-sheet formulas). These parse as 0 rows after formula error handling — the `count($result['rows']) > 0` filter automatically skips them.
