---
name: uv-tool-install
description: Install Python tools via `uv tool install` on Windows + git-bash (MSYS) without hitting the PowerShell-only PATH warning. Covers editable installs, persistent PATH, and the verification command.
---

# uv tool install on Windows + git-bash

`uv tool install` works fine on Windows, but its post-install PATH reminder assumes PowerShell. Under git-bash / MSYS the suggested command (`$env:PATH = ...`) does nothing in your shell. This skill is the working substitute.

Use this skill whenever the task is: install a Python CLI published as a tool (PyPI or editable local checkout) and the host is Windows + git-bash.

## Why the warning misleads

After a successful install, uv prints:

```
warning: `C:\Users\<you>\.local\bin` is not on your PATH. To use installed tools,
run `$env:PATH = "C:\Users\<you>\.local\bin;$env:PATH"` or `uv tool update-shell`.
```

`$env:PATH = ...` is PowerShell syntax. In git-bash this fails silently (or with a syntax error depending on quoting). `uv tool update-shell` *does* work — it appends the export to `~/.bashrc` — but only after the install is done, so you still hit the warning on the install that needs the PATH.

Fix: append the export yourself to all three of the standard login files. Idempotent — safe to re-run.

## Procedure

Run from the project root (or anywhere — last `cd` matters only for `-e .` editable installs):

```bash
# 1. Install globally (non-editable, from PyPI)
uv tool install <package-name>

# OR editable (for a project you've cloned)
uv tool install -e .

# 2. Persist PATH for all future git-bash sessions (idempotent)
PERSIST_LINE='export PATH="$HOME/.local/bin:$PATH"'
for f in "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.profile"; do
  touch "$f"
  grep -qF '.local/bin' "$f" || echo "$PERSIST_LINE" >> "$f"
done

# 3. Verify in a NEW shell (current shell needs source ~/.bashrc, new terminal doesn't)
"$HOME/.local/bin/<tool>.exe" --version   # Windows → always ends in .exe
PATH="$HOME/.local/bin:$PATH" command -v <tool>
```

The `.exe` suffix on Windows is not optional — quoting `browser-harness.exe` vs `browser-harness` matters. `command -v` checks only the unqualified name on PATH.

## Editable install repos: prefer a stable path

For `-e .` (editable) installs, clone into a durable location like `~/Developer/<name>`, not `/tmp`. Otherwise the install breaks the next time `/tmp` is cleaned. `install.md` from browser-harness states this preference verbatim; treat it as the default rule for any editable uv-tool install.

## Verification matrix

| Check                              | Command                                                   | Pass =                  |
| ---------------------------------- | --------------------------------------------------------- | ----------------------- |
| Binary present                     | `ls "$HOME/.local/bin/<tool>.exe"`                        | file exists             |
| Binary runs                        | `"$HOME/.local/bin/<tool>.exe" --version`                 | prints version          |
| PATH wired for current shell       | `PATH="$HOME/.local/bin:$PATH" command -v <tool>`         | resolved path           |
| PATH wired for future shells       | grep `.local/bin` `~/.bashrc`                             | one match               |

If 1–3 pass but 4 fails, you forgot step 2 — re-run it.

## Pitfalls

- **The warning is cosmetic on success.** Don't roll back the install because of it. Confirm the binary actually exists at `~/.local/bin/` first.
- **Don't trust `uv tool update-shell` blindly on Windows.** It writes to `~/.bashrc` for MSYS but may not detect Cygwin or other shells. The explicit `grep -qF` / `echo >>` loop above is portable.
- **An editable install can be "cleanly" cloned from a workdir under a path with no spaces or unicode.** Spaces in `$HOME` paths (uncommon but possible) have bitten `uv` resolver bug reports; if the install mysteriously fails to resolve, move the repo to `~/Developer/`.
- **`$env:FOO` references in install instructions are PowerShell, not bash.** When copying install steps from upstream READMEs that target Windows, mentally translate `$env:NAME` to `${NAME}` (or `"$NAME"`).

## When NOT to use this skill

- Pure POSIX (Linux/macOS): `uv tool update-shell` just works; no need for the manual loop.
- Pure PowerShell on Windows: use the `$env:PATH = ...` line uv prints; don't fight it.
- Installing into a project venv (not a global tool): use `uv add <pkg>` or `pip install` instead — `-e .` and `uv tool install -e .` are not the same thing.
