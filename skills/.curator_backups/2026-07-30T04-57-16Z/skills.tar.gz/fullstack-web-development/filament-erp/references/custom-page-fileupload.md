# Custom Filament Page with FileUpload — Array/String Gotcha

## Background
`CompanySetting` model stores ALL values (text, select, file path) as plain strings in `value` column. Filament `FileUpload` component expects **array** values (e.g. `['company/logo.png']`) in its state, but the DB returns `'company/logo.png'` (string). This mismatch causes `foreach() argument must be of type array|object, string given` at `BaseFileUpload.php:740`.

## Fix Pattern: Custom Page mount() + save()

```php
class ProfilTemplatePage extends Page
{
    use InteractsWithForms;
    
    public ?array $data = [];
    public $settingRecords = [];

    public function mount(): void
    {
        $this->settingRecords = CompanySetting::whereIn('group', ['profil', 'template'])->get();
        $values = [];
        foreach ($this->settingRecords as $s) { $values[$s->key] = $s->value; }
        $this->data = $values;

        // CRITICAL: FileUpload expects array, DB stores string
        foreach (['company_logo', 'director_signature'] as $f) {
            if (isset($this->data[$f]) && is_string($this->data[$f])) {
                $this->data[$f] = [$this->data[$f]];
            }
        }
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            FileUpload::make('company_logo')
                ->image()
                ->disk('public')          // ← REQUIRED for local storage
                ->directory('company')
                ->maxSize(2048),
            FileUpload::make('director_signature')
                ->image()
                ->disk('public')          // ← REQUIRED
                ->directory('company')
                ->maxSize(1024),
        ])->statePath('data');
    }

    public function save(): void
    {
        // MUST use form->getState() — NOT $this->data — so FileUpload
        // processes temporary file keys into final paths
        $state = $this->form->getState();
        $formData = $state['data'] ?? $state;

        $fileFields = ['company_logo', 'director_signature'];
        foreach ($formData as $key => $value) {
            if (in_array($key, $fileFields) && $value === null) continue;
            if (in_array($key, $fileFields) && is_array($value)) {
                $value = $value[0] ?? null;
                if ($value === null) continue;
            }
            CompanySetting::set($key, $value);
        }
        // Sync back so form re-renders with correct values
        $this->data = $formData;
    }
}
```

## Root Cause
- `$this->data = $values` bypasses Filament's form processing pipeline
- FileUpload stores a **Livewire temporary key** (e.g. `livewire-file-abc123`) as the value in `$this->data`
- `$this->form->getState()` triggers the move from temp → permanent storage and returns the final path
- Using `$this->data` directly in `save()` stores the temp key → image never saved

## Always
1. Add `->disk('public')` on every FileUpload (default disk is `local`, not web-accessible)
2. Use `$this->form->getState()` in save(), not `$this->data`
3. Convert string→array in mount for file fields
4. Convert array→string in save for file fields
5. Sync `$this->data = $formData` after save for proper re-render
