# PDF Base Layout Pattern

## Problem
4+ document-type PDFs (penawaran, faktur, RAB, invoice) each duplicated company header, logo, signature, footer, bank info, notes. Editing header/signature required touching every file.

## Solution
`resources/views/pdf/base.blade.php` — shared layout. Child extends it with content-only sections.

### Base handles:
- Company logo + profile (from `CompanySetting`)
- Document title area (`@yield('doc_title')`)
- Recipient (`@yield('kepada')`)
- Info table (`@yield('info')`)
- Main content table (`@yield('content')`)
- Terbilang (`@yield('terbilang')`)
- Default notes (per doc-type from `CompanySetting`)
- Bank info (hidden for RAB)
- Signature (director name + ttd image)
- Footer

### Doc-type-specific settings
Base auto-reads from `CompanySetting` using `$docType` prefix:
```php
$docPrefix = $docType ?? 'penawaran';
$showProfile = App\Models\CompanySetting::get($docPrefix . '_show_company_profile', 'true') === 'true';
$showSignature = App\Models\CompanySetting::get($docPrefix . '_show_signature', 'true') === 'true';
$defaultNotes = App\Models\CompanySetting::get($docPrefix . '_default_notes', '');
```

### Child example (penawaran)
```blade
@php $docType = 'penawaran'; $docNumber = $penawaran->nomor_penawaran; @endphp
@extends('pdf.base', ['docType' => $docType, 'docNumber' => $docNumber])

@section('doc_title', 'SURAT PENAWARAN')
@section('doc_subtitle', 'No. ' . $penawaran->nomor_penawaran)
@section('kepada', $penawaran->nama_klien)

@section('info')
<table class="info-table">
    <tr><td>Tanggal</td><td>{{ $penawaran->tanggal_penawaran->format('d F Y') }}</td></tr>
    <tr><td>Masa Berlaku</td><td>{{ $penawaran->masa_berlaku }} hari</td></tr>
</table>
@endsection

@section('content')
<table class="items">
    <thead><tr><th>No</th><th>Uraian</th><th>Qty</th><th>Harga</th><th>Jumlah</th></tr></thead>
    <tbody>@foreach($penawaran->items as $i => $item) ... @endforeach</tbody>
</table>
<table class="summary-table"><tr class="grand-line">...</tr></table>
@endsection
```

### Files refactored (2026-07-30)
- `pdf/penawaran.blade.php` → extends base (70% shorter)
- `pdf/faktur.blade.php` → extends base (65% shorter)
- `pdf/rab.blade.php` → extends base (60% shorter)
- `pdf/bast.blade.php` → unchanged (unique legal format)
- `pdf/laporan-pekerjaan.blade.php` → unchanged (complex content)

## Benefit
- Edit header/signature/footer once in `base.blade.php` → all docs update
- Consistent layout, font, spacing across documents
- New doc type = one small child file
